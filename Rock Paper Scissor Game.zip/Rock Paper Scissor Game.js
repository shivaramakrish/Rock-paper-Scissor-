let rockBtn = document.getElementById('rockBtn');
let paperBtn = document.getElementById('paperBtn');
let scissorBtn = document.getElementById('scissorBtn');
let yourValue = document.getElementById('yourValue');
let comValue = document.getElementById('comValue');
let gameResult = document.getElementById('gameResult');
let heightScore = document.getElementById('heightScore');
let computerValue;
let rounds = 0;

function game() {
    rounds += 1;
}

function random() {
    let gameArray = ["Rock", "Paper", "Scissor"]
    let index = Math.floor(Math.random() * gameArray.length);
    return gameArray[index]

}
random()

rockBtn.addEventListener('click', function() {
    computerValue = random()
    yourValue.textContent = "Rock"
    comValue.textContent = computerValue

    if ("Rock" === computerValue) {
        gameResult.textContent = "Tie"
    } else if (computerValue === "Paper") {
        gameResult.textContent = "Lost"
    } else {
        gameResult.textContent = "You Won"
    }
})

paperBtn.addEventListener('click', function() {
    computerValue = random()
    yourValue.textContent = "Paper"
    comValue.textContent = computerValue

    if ("Paper" === computerValue) {
        gameResult.textContent = "Tie"
    } else if (computerValue === "Scissor") {
        gameResult.textContent = "Lost"
    } else {
        gameResult.textContent = "You Won"
    }
})

scissorBtn.addEventListener('click', function() {
    computerValue = random()
    yourValue.textContent = "Scissor"
    comValue.textContent = computerValue

    if ("Scissor" === computerValue) {
        gameResult.textContent = "Tie"
    } else if (computerValue === "Rock") {
        gameResult.textContent = "Lost"
    } else {
        gameResult.textContent = "You Won"
    }
})